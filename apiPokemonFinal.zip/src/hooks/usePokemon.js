import { useEffect, useState } from 'react';
import { pokemonsArr } from '../helpers/pokemonsArr';

export const usePokemon = () => {
  const [pokemons, setPokemons] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  useEffect(() => {
    //Está en el useEffect porque sino sería un ciclo infinito
    pokemonsArr().then((pokemons) => {
      setIsLoading(false);  //para que la pagina no quede cargando
      setPokemons(pokemons);
    });
    return () => {};
  }, []);
  return { pokemons, isLoading };
};
